# موقع امتحان التربية الإسلامية - الوحدة الأولى (نموذج أ)

الملفات:
- `index.html`  واجهة الطالب (لا تحتوي أي إجابات).
- `server.py`   السيرفر: يقدّم الصفحة والأسئلة، يصحّح الإجابات، يحفظ النتائج، ويصدّرها Excel. لا يحتاج أي مكتبات.
- `questions.json`  الأسئلة والإجابات الصحيحة (على السيرفر فقط ولا تُرسل للطالب إلا بعد إنهاء المراقب).
- `render.yaml`  إعداد النشر على Render.

## كلمات المرور
تُضبط بمتغيرات بيئة على السيرفر، ولا تُكتب في الكود:
- `START_PASSWORD`  كلمة بدء الامتحان (يعطيها المراقب للطلاب).
- `END_PASSWORD`    كلمة المراقب (إنهاء الامتحان وتصدير Excel).
- `EXAM_SIZE`       (اختياري) عدد الأسئلة لكل طالب، الافتراضي 30 من أصل 42، تُختار عشوائيًا لكل طالب.

بدونها يستخدم السيرفر كلمات افتراضية للتجربة فقط (Start@2026 / Moraqeb@2026).

## التشغيل المحلي
    START_PASSWORD=abc END_PASSWORD=xyz python server.py     # ويندوز: set START_PASSWORD=abc ثم set END_PASSWORD=xyz
ثم افتح http://localhost:8000 (الطلاب على نفس الشبكة: http://IP-الجهاز:8000).

## الرفع على GitHub (اجعل المستودع Private)
    git init
    git add .
    git commit -m "exam site"
    git branch -M main
    git remote add origin https://github.com/USERNAME/REPO.git
    git push -u origin main

GitHub Pages لا يصلح هنا لأنه يستضيف ملفات ثابتة فقط ولا يشغّل server.py.

## النشر على Render
1. New > Web Service > اربط المستودع، أو New > Blueprint لاستخدام render.yaml.
2. Start Command: `python server.py`  |  Build Command: فارغ.
3. Environment: أضف `START_PASSWORD` و `END_PASSWORD`.
4. للحفظ الدائم للنتائج: خطة مدفوعة + Disk مركّب على `/var/data` + المتغير `DATA_DIR=/var/data`.
   على الخطة المجانية تُمسح النتائج عند كل إعادة تشغيل، فصدّر Excel مباشرة بعد الامتحان.

## النشر على سيرفر عادي (Ubuntu)
    sudo apt update && sudo apt install -y python3 git nginx
    sudo git clone https://github.com/USERNAME/REPO.git /opt/exam

`/etc/systemd/system/exam.service`:

    [Unit]
    Description=Exam server
    After=network.target
    [Service]
    WorkingDirectory=/opt/exam
    Environment=PORT=8000
    Environment=DATA_DIR=/var/lib/exam
    Environment=START_PASSWORD=غيّرها
    Environment=END_PASSWORD=غيّرها
    ExecStart=/usr/bin/python3 /opt/exam/server.py
    Restart=always
    User=www-data
    StateDirectory=exam
    [Install]
    WantedBy=multi-user.target

    sudo systemctl enable --now exam

`/etc/nginx/sites-available/exam`:

    server {
        server_name exam.example.com;
        location / {
            proxy_pass http://127.0.0.1:8000;
            proxy_set_header X-Forwarded-For $remote_addr;
        }
    }

    sudo ln -s /etc/nginx/sites-available/exam /etc/nginx/sites-enabled/
    sudo nginx -t && sudo systemctl reload nginx
    sudo apt install -y certbot python3-certbot-nginx && sudo certbot --nginx -d exam.example.com

## طريقة الاستخدام يوم الامتحان
1. يفتح الطلاب الرابط، يكتبون الاسم ويختارون التخصص والشعبة، ويدخلون كلمة البدء.
2. أسئلة كل طالب بترتيب عشوائي، وخياراتها كذلك.
3. المراقب يضغط «إنهاء الامتحان» على جهاز الطالب ويدخل كلمته: تُصحَّح الإجابات على السيرفر وتُحفظ وتظهر العلامة.
4. من أي جهاز: «تصدير النتائج إلى Excel» بكلمة المراقب.
